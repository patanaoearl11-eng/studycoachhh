<?php
session_start();

// Dummy user session for testing
if (!isset($_SESSION['user'])) {
    $_SESSION['user'] = 'testuser';
}

// Temporary logout handling
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>StudyCoach - Dashboard (Portrait)</title>
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="h-screen flex text-white" style="background: linear-gradient(to bottom, #0f172a, #1e293b);">

<!-- Sidebar -->
<aside class="w-64 bg-gray-900 flex flex-col p-6">
  <h1 class="text-2xl font-bold mb-10 text-blue-400">📘 StudyCoach</h1>
  <nav class="flex flex-col space-y-4">
    <a href="mainpage.html" class="text-left hover:text-blue-400 transition transform hover:scale-110">🏠 Home</a>

  
    <!-- Create Reviewer Dropdown -->
    <div>
      <button onclick="toggleSubjects()" class="w-full text-left hover:text-blue-400 transition flex items-center justify-between transform hover:scale-110">
        ➕ Create Reviewer 
        <span id="arrow" class="transform transition-transform">▼</span>
      </button>

      <!-- Subject list (hidden by default) -->
      <div id="subjectList" class="hidden mt-2 ml-4 flex flex-col space-y-2">
        <a href="create_python.php" class="hover:text-blue-300 transition transform hover:scale-110">🐍 Python Fundamentals</a>
        <a href="create_htmlcss.php" class="hover:text-blue-300 transition transform hover:scale-110">🌐 HTML & CSS Fundamentals</a>
        <a href="create_php.php" class="hover:text-blue-300 transition transform hover:scale-110">💻 PHP Fundamentals</a>
        <a href="create_java.php" class="hover:text-blue-300 transition transform hover:scale-110">☕ Java Fundamentals</a>
        <a href="create_networking.php" class="hover:text-blue-300 transition transform hover:scale-110">🖧 Networking Fundamentals</a>
      </div>
    </div>

    <!-- Smart Quiz Generator -->
    <button onclick="showSection('quiz')" class="text-left hover:text-blue-400 transition transform hover:scale-110">🧠 Smart Quiz Generator</button>

    <!-- My Reviewers -->
    <button onclick="showSection('myReviewers')" class="text-left hover:text-blue-400 transition transform hover:scale-110">📚 My Reviewers</button>

    <button onclick="showSection('studyTracker')" class="text-left hover:text-blue-400 transition transform hover:scale-110">📊 Study Tracker</button>


    <button onclick="showSection('achievements')" class="text-left hover:text-blue-400 transition transform hover:scale-110">
  🏆 Achievements
</button>



    <!-- Exam Schedules -->
    <button onclick="showSection('scheduleSessions')" class="text-left hover:text-blue-400 transition transform hover:scale-110">📅 Schedule Sessions</button>

    <a href="dashboard.html" 
       class="text-1xl text-blue-400 hover:text-blue-700 font-bold transition transform hover:scale-110">
       🔙 Return to Dashboard
    </a>

   <a href="#"
   onclick="confirmLogout(event)"
   class="text-left hover:text-red-400 transition transform hover:scale-110">
   🚪 Logout


<script>
function confirmLogout(event) {
  event.preventDefault(); // Prevents the link from immediately redirecting
  const confirmed = confirm("Are you sure you want to log out?");
  if (confirmed) {
    window.location.href = "mainpage.html"; // ✅ Redirects to mainpage.html
  }
}
</script>
  </nav>
</aside>

<!-- Main Content -->
<main class="flex-1 p-10 overflow-y-auto">  

  <!-- HOME SECTION -->
  <section id="home">
    <h1 class="text-4xl font-bold mb-10 text-blue-400">WELCOME TO STUDYCOACH: DASHBOARD</h1>

   
      <div onclick="showSection('uploadOrganize')"
     class="cursor-pointer block bg-gradient-to-br from-gray-800 to-gray-700 p-10 rounded-3xl shadow-xl   hover:shadow-blue-600/50 hover:-translate-y-2 transition-all duration-300">
       <h2 class="text-2xl font-semibold mb-3 text-blue-400">📂 Upload & Organize</h2>
       <p class="text-gray-300 text-lg">
          Easily upload study materials, notes, and documents. Automatically organize them by subjects or topics for faster access.
            </p>
        </div>

      <div onclick="showSection('myReviewers')" 
        class="block bg-gradient-to-br from-gray-800 to-gray-700 p-10 rounded-3xl shadow-xl hover:shadow-blue-600/50 hover:-translate-y-2 transition-all duration-300">
        <h2 class="text-2xl font-semibold mb-3 text-blue-400">📚 My Reviewers</h2>
        <p class="text-gray-300 text-lg">Access all your saved reviewers, practice tests, and summaries in one place for quick study sessions.</p>
      </div>

      <div onclick="showSection('studyTracker')" 
  class="cursor-pointer block bg-gradient-to-br from-gray-800 to-gray-700 p-10 rounded-3xl shadow-xl hover:shadow-blue-600/50 hover:-translate-y-2 transition-all duration-300">
  <h2 class="text-2xl font-semibold mb-3 text-blue-400">📊 Study Tracker</h2>
  <p class="text-gray-300 text-lg">Track your progress with visual indicators to help you see what subjects or topics you need to review more.</p>
</div>


      <div onclick="showSection('recommendations')" 
  class="cursor-pointer block bg-gradient-to-br from-gray-800 to-gray-700 p-10 rounded-3xl shadow-xl hover:shadow-blue-600/50 hover:-translate-y-2 transition-all duration-300">
  <h2 class="text-2xl font-semibold mb-3 text-blue-400">🤖 Study Coach Recommendations</h2>
  <p class="text-gray-300 text-lg">Get personalized study tips and subject focus recommendations based on your recent activity and progress.</p>
</div>

    </div>
  </section>

  <!-- SMART QUIZ GENERATOR SECTION -->
  <section id="quiz" class="hidden">
    <h1 class="text-4xl font-bold mb-8 text-blue-400">🧠 Smart Quiz Generator</h1>
    <p class="text-gray-300 text-lg mb-10">Choose a type of quiz to start generating practice questions automatically.</p>

    <div class="grid grid-cols-1 md:grid-cols-2 gap-8">

      <!-- Multiple Choice (Clickable) -->
      <div onclick="showSection('multipleChoiceSubjects')" 
           class="cursor-pointer bg-gradient-to-br from-gray-800 to-gray-700 p-8 rounded-2xl shadow-lg hover:shadow-blue-600/40 hover:-translate-y-2 transition-all duration-300">
        <h2 class="text-xl font-semibold mb-2 text-blue-400">❓ Multiple Choice</h2>
        <p class="text-gray-300">Answer questions with multiple options — great for testing quick recall and topic coverage.</p>
      </div>

      <!-- Identification (Clickable) -->
      <div onclick="showSection('identificationSubjects')" 
           class="cursor-pointer bg-gradient-to-br from-gray-800 to-gray-700 p-8 rounded-2xl shadow-lg hover:shadow-blue-600/40 hover:-translate-y-2 transition-all duration-300">
        <h2 class="text-xl font-semibold mb-2 text-blue-400">✏️ Identification</h2>
        <p class="text-gray-300">Provide short answers to test your ability to identify key concepts and terms.</p>
      </div>

    
      <!-- True or False card -->
<div onclick="showSection('trueFalseSubjects')" 
     class="cursor-pointer bg-gradient-to-br from-gray-800 to-gray-700 p-8 rounded-2xl shadow-lg hover:shadow-blue-600/40 hover:-translate-y-2 transition-all duration-300">
  <h2 class="text-xl font-semibold mb-2 text-blue-400">✅ True or False</h2>
  <p class="text-gray-300">Decide whether each statement is true or false — a fast-paced knowledge check.</p>
</div>


      <!-- Essay card -->
<div onclick="showSection('essaySubjects')" 
     class="cursor-pointer bg-gradient-to-br from-gray-800 to-gray-700 p-8 rounded-2xl shadow-lg hover:shadow-blue-600/40 hover:-translate-y-2 transition-all duration-300">
  <h2 class="text-xl font-semibold mb-2 text-blue-400">🧾 Essay</h2>
  <p class="text-gray-300">Write short or long-form answers to explain ideas in your own words.</p>
</div>
      <!-- Mixed Quiz card -->
      <div onclick="showSection('mixedSubjects')" 
     class="cursor-pointer bg-gradient-to-br from-gray-800 to-gray-700 p-8 rounded-2xl shadow-lg hover:shadow-blue-600/40 hover:-translate-y-2 transition-all duration-300">
  <h2 class="text-xl font-semibold mb-2 text-blue-400">🎯 Mixed Quiz</h2>
  <p class="text-gray-300">Combine multiple question types for a complete review experience.</p>
</div>


      <!-- Code Snippet card -->
<div onclick="showSection('codeSnippetSubjects')" 
     class="cursor-pointer bg-gradient-to-br from-gray-800 to-gray-700 p-8 rounded-2xl shadow-lg hover:shadow-blue-600/40 hover:-translate-y-2 transition-all duration-300">
  <h2 class="text-xl font-semibold mb-2 text-blue-400">💡 Code Snippet</h2>
  <p class="text-gray-300">Complete the code by filling out all the blanks.</p>
</div>

      <!-- Matching Type card -->
<div onclick="showSection('matchingSubjects')" 
     class="cursor-pointer bg-gradient-to-br from-gray-800 to-gray-700 p-8 rounded-2xl shadow-lg hover:shadow-blue-600/40 hover:-translate-y-2 transition-all duration-300">
  <h2 class="text-xl font-semibold mb-2 text-blue-400">🔗 Matching Type</h2>
  <p class="text-gray-300">Respond to matching questions by pairing each of a set of stems.</p>
</div>


    </div>
  </section>

  <!-- MULTIPLE CHOICE SUBJECTS SECTION -->
  <section id="multipleChoiceSubjects" class="hidden p-10">
    <h1 class="text-4xl font-bold mb-8 text-blue-400">❓ Choose a Subject (Multiple Choice)</h1>
    <p class="text-gray-300 mb-10 text-lg">Select a subject below to start your multiple-choice quiz.</p>

    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      <a href="mcq_python.php" class="subject-link">🐍 Python Fundamentals</a>
      <a href="mcq_htmlcss.php" class="subject-link">🌐 HTML & CSS Fundamentals</a>
      <a href="mcq_php.php" class="subject-link">💻 PHP Fundamentals</a>
      <a href="mcq_java.php" class="subject-link">☕ Java Fundamentals</a>
      <a href="mcq_networking.php" class="subject-link">🖧 Networking Fundamentals</a>
    </div>

    <button onclick="showSection('quiz')" class="back-button">🔙 Back to Quiz Options</button>
  </section>

  <!-- IDENTIFICATION SUBJECTS SECTION -->
  <section id="identificationSubjects" class="hidden p-10">
    <h1 class="text-4xl font-bold mb-8 text-blue-400">✏️ Choose a Subject (Identification)</h1>
    <p class="text-gray-300 mb-10 text-lg">Select a subject below to start your identification quiz.</p>

    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      <a href="identification_python.php" class="subject-link">🐍 Python Fundamentals</a>
      <a href="identification_htmlcss.php" class="subject-link">🌐 HTML & CSS Fundamentals</a>
      <a href="identification_php.php" class="subject-link">💻 PHP Fundamentals</a>
      <a href="identification_java.php" class="subject-link">☕ Java Fundamentals</a>
      <a href="identification_networking.php" class="subject-link">🖧 Networking Fundamentals</a>
    </div>

    <button onclick="showSection('quiz')" class="back-button">🔙 Back to Quiz Options</button>
  </section>

 <!-- TRUE OR FALSE SUBJECTS SECTION -->
<section id="trueFalseSubjects" class="hidden p-10">
  <h1 class="text-4xl font-bold mb-8 text-blue-400">✅ Choose a Subject (True or False)</h1>
  <p class="text-gray-300 mb-10 text-lg">Select a subject below to start your True or False quiz.</p>

  <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
    <a href="tf_python.php" class="subject-link">🐍 Python Fundamentals</a>
    <a href="tf_htmlcss.php" class="subject-link">🌐 HTML & CSS Fundamentals</a>
    <a href="tf_php.php" class="subject-link">💻 PHP Fundamentals</a>
    <a href="tf_java.php" class="subject-link">☕ Java Fundamentals</a>
    <a href="tf_networking.php" class="subject-link">🖧 Networking Fundamentals</a>
  </div>

  <button onclick="showSection('quiz')" class="back-button">🔙 Back to Quiz Options</button>
</section>

<!-- ESSAY SUBJECTS SECTION -->
<section id="essaySubjects" class="hidden p-10">
  <h1 class="text-4xl font-bold mb-8 text-blue-400">🧾 Choose a Subject (Essay)</h1>
  <p class="text-gray-300 mb-10 text-lg">Select a subject below to start your Essay quiz.</p>

  <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
    <a href="essay_python.php" class="subject-link">🐍 Python Fundamentals</a>
    <a href="essay_htmlcss.php" class="subject-link">🌐 HTML & CSS Fundamentals</a>
    <a href="essay_php.php" class="subject-link">💻 PHP Fundamentals</a>
    <a href="essay_java.php" class="subject-link">☕ Java Fundamentals</a>
    <a href="essay_networking.php" class="subject-link">🖧 Networking Fundamentals</a>
  </div>

  <button onclick="showSection('quiz')" class="back-button">🔙 Back to Quiz Options</button>
</section>

<!-- MIXED QUIZ SUBJECTS SECTION -->
<section id="mixedSubjects" class="hidden p-10">
  <h1 class="text-4xl font-bold mb-8 text-blue-400">🎯 Choose a Subject (Mixed Quiz)</h1>
  <p class="text-gray-300 mb-10 text-lg">Select a subject below to start your Mixed Quiz.</p>

  <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
    <a href="mixed_python.php" class="subject-link">🐍 Python Fundamentals</a>
    <a href="mixed_htmlcss.php" class="subject-link">🌐 HTML & CSS Fundamentals</a>
    <a href="mixed_php.php" class="subject-link">💻 PHP Fundamentals</a>
    <a href="mixed_java.php" class="subject-link">☕ Java Fundamentals</a>
    <a href="mixed_networking.php" class="subject-link">🖧 Networking Fundamentals</a>
  </div>

  <button onclick="showSection('quiz')" class="back-button">🔙 Back to Quiz Options</button>
</section>

<!-- CODE SNIPPET SUBJECTS SECTION -->
<section id="codeSnippetSubjects" class="hidden p-10">
  <h1 class="text-4xl font-bold mb-8 text-blue-400">💡 Choose a Subject (Code Snippet)</h1>
  <p class="text-gray-300 mb-10 text-lg">Select a subject below to start your Code Snippet quiz.</p>

  <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
    <a href="codesnippet_python.php" class="subject-link">🐍 Python Fundamentals</a>
    <a href="codesnippet_htmlcss.php" class="subject-link">🌐 HTML & CSS Fundamentals</a><br> 
    <a href="codesnippet_php.php" class="subject-link">💻 PHP Fundamentals</a>
    <a href="codesnippet_java.php" class="subject-link">☕ Java Fundamentals</a>
    
  </div>

  <button onclick="showSection('quiz')" class="back-button">🔙 Back to Quiz Options</button>
</section>

<!-- MATCHING TYPE SUBJECTS SECTION -->
<section id="matchingSubjects" class="hidden p-10">
  <h1 class="text-4xl font-bold mb-8 text-blue-400">🔗 Choose a Subject (Matching Type)</h1>
  <p class="text-gray-300 mb-10 text-lg">Select a subject below to start your Matching Type quiz.</p>

  <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
    <a href="matching_python.php" class="subject-link">🐍 Python Fundamentals</a>
    <a href="matching_htmlcss.php" class="subject-link">🌐 HTML & CSS Fundamentals</a>
    <a href="matching_php.php" class="subject-link">💻 PHP Fundamentals</a>
    <a href="matching_java.php" class="subject-link">☕ Java Fundamentals</a>
    <a href="matching_networking.php" class="subject-link">🖧 Networking Fundamentals</a>
  </div>

  <button onclick="showSection('quiz')" class="back-button">🔙 Back to Quiz Options</button>
</section>

<!-- UPLOAD & ORGANIZE SECTION -->

<section id="uploadOrganize" class="hidden p-10">
  <h1 class="text-5xl font-bold mb-6 text-center">
    Transform <span class="text-blue-400">Chaos</span> into <span class="text-blue-400">Clarity</span>
  </h1>
  <p class="text-gray-300 text-center mb-10 max-w-3xl mx-auto">
    Upload your study materials and watch them transform into organized, interactive digital formats. 
    From handwritten notes to complex documents — we make everything searchable and study-ready.
  </p>


  <!-- Upload Box -->
  <div class="bg-gradient-to-br from-gray-800 to-gray-700 border border-gray-600 p-12 rounded-3xl shadow-lg text-center">
    <div class="border-2 border-dashed border-gray-500 rounded-2xl p-12 hover:border-blue-400 transition">
      <svg xmlns="http://www.w3.org/2000/svg" class="mx-auto mb-4 h-16 w-16 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
              d="M3 15a4 4 0 01.88-2.53l7.12-8.72a4 4 0 016 0l7.12 8.72A4 4 0 0121 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4z" />
      </svg>
      <p class="text-xl mb-4 font-semibold text-blue-300">Drop your study materials here</p>
      <p class="text-gray-400 mb-4">or click to browse and select files</p>
      <form action="upload_handler.php" method="POST" enctype="multipart/form-data" class="space-y-4">
        <input type="file" name="studyFiles[]" multiple
               accept=".pdf,.docx,.jpg,.png,.txt,.pptx"
               class="block w-full text-gray-200 bg-gray-900 border border-gray-700 rounded-lg cursor-pointer p-3">
        <button type="submit"
                class="mt-6 px-8 py-3 bg-blue-500 hover:bg-blue-600 text-white rounded-xl font-semibold shadow-lg transition">
          Choose Files
        </button>
      </form>
      <div class="mt-6 flex justify-center space-x-3 text-gray-400 text-sm">
        <span class="bg-gray-700 px-3 py-1 rounded-lg">PDF</span>
        <span class="bg-gray-700 px-3 py-1 rounded-lg">DOCX</span>
        <span class="bg-gray-700 px-3 py-1 rounded-lg">JPG</span>
        <span class="bg-gray-700 px-3 py-1 rounded-lg">PNG</span>
        <span class="bg-gray-700 px-3 py-1 rounded-lg">TXT</span>
        <span class="bg-gray-700 px-3 py-1 rounded-lg">PPTX</span>
      </div>
    </div>
  </div>
  <button onclick="showSection('home')" class="back-button">🔙 Back to Home</button>
</section>

<!-- MY REVIEWERS SECTION -->
<section id="myReviewers" class="hidden p-10">
  <h1 class="text-4xl font-bold mb-8 text-blue-400">📚 My Reviewers</h1>
  <p class="text-gray-300 text-lg mb-10">
    Access all your saved reviewers, practice tests, and summaries in one place for quick study sessions.
  </p>

  <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">

    <a href="reviewer_python.php" 
       class="subject-link hover:shadow-blue-600/40 hover:-translate-y-2 transition-all duration-300">
      🐍 Python Fundamentals
    </a>

    <a href="reviewer_htmlcss.php" 
       class="subject-link hover:shadow-blue-600/40 hover:-translate-y-2 transition-all duration-300">
      🌐 HTML & CSS Fundamentals
    </a>

    <a href="reviewer_php.php" 
       class="subject-link hover:shadow-blue-600/40 hover:-translate-y-2 transition-all duration-300">
      💻 PHP Fundamentals
    </a>

    <a href="reviewer_java.php" 
       class="subject-link hover:shadow-blue-600/40 hover:-translate-y-2 transition-all duration-300">
      ☕ Java Fundamentals
    </a>

    <a href="reviewer_networking.php" 
       class="subject-link hover:shadow-blue-600/40 hover:-translate-y-2 transition-all duration-300">
      🖧 Networking Fundamentals
    </a>
  </div>

  <button onclick="showSection('home')" class="back-button">🔙 Back to Home</button>
</section>


<!-- STUDY TRACKER SECTION -->
<section id="studyTracker" class="hidden p-10">
  <h1 class="text-4xl font-bold mb-8 text-blue-400">📊 Study Tracker</h1>
  <p class="text-gray-300 text-lg mb-10">
    Track your progress with visual indicators to help you see what subjects or topics you need to review more.
  </p>

  <div class="space-y-8">

    <!-- Python Progress -->
    <div>
      <div class="flex justify-between mb-2">
        <span class="text-lg font-semibold text-blue-300">🐍 Python Fundamentals</span>
        <span class="text-gray-400">0%</span>
      </div>
      <div class="w-full bg-gray-700 rounded-full h-4">
        <div class="bg-blue-500 h-4 rounded-full" style="width: 0%;"></div>
      </div>
    </div>

    <!-- HTML & CSS Progress -->
    <div>
      <div class="flex justify-between mb-2">
        <span class="text-lg font-semibold text-blue-300">🌐 HTML & CSS Fundamentals</span>
        <span class="text-gray-400">0%</span>
      </div>
      <div class="w-full bg-gray-700 rounded-full h-4">
        <div class="bg-blue-400 h-4 rounded-full" style="width: 0%;"></div>
      </div>
    </div>

    <!-- PHP Progress -->
    <div>
      <div class="flex justify-between mb-2">
        <span class="text-lg font-semibold text-blue-300">💻 PHP Fundamentals</span>
        <span class="text-gray-400">0%</span>
      </div>
      <div class="w-full bg-gray-700 rounded-full h-4">
        <div class="bg-green-500 h-4 rounded-full" style="width: 0%;"></div>
      </div>
    </div>

    <!-- Java Progress -->
    <div>
      <div class="flex justify-between mb-2">
        <span class="text-lg font-semibold text-blue-300">☕ Java Fundamentals</span>
        <span class="text-gray-400">0%</span>
      </div>
      <div class="w-full bg-gray-700 rounded-full h-4">
        <div class="bg-yellow-500 h-4 rounded-full" style="width: 0%;"></div>
      </div>
    </div>

    <!-- Networking Progress -->
    <div>
      <div class="flex justify-between mb-2">
        <span class="text-lg font-semibold text-blue-300">🖧 Networking Fundamentals</span>
        <span class="text-gray-400">0%</span>
      </div>
      <div class="w-full bg-gray-700 rounded-full h-4">
        <div class="bg-red-500 h-4 rounded-full" style="width: 0%;"></div>
      </div>
    </div>
  </div>

  <button onclick="showSection('home')" class="back-button">🔙 Back to Home</button>
</section>


<!-- STUDY COACH RECOMMENDATIONS SECTION -->
<section id="recommendations" class="hidden p-10">
  <h1 class="text-4xl font-bold mb-8 text-blue-400">🤖 Study Coach Recommendations</h1>
  <p class="text-gray-300 text-lg mb-10">
    Get personalized study tips and focus recommendations based on your latest activity and progress.
  </p>

  <!-- Personalized Tips Box -->
  <div class="bg-gradient-to-br from-gray-800 to-gray-700 p-10 rounded-3xl shadow-xl space-y-6">

    <div>
      <h2 class="text-2xl font-semibold text-blue-300 mb-2">🎯 Focus Areas</h2>
      <ul class="list-disc list-inside text-gray-300">
        <li>Focus more on <span class="text-blue-400 font-semibold">Networking Fundamentals</span> — progress at 35%.</li>
        <li>Revisit <span class="text-blue-400 font-semibold">HTML & CSS Fundamentals</span> — progress at 45%.</li>
        <li>Maintain your strong performance in <span class="text-green-400 font-semibold">PHP Fundamentals</span>.</li>
      </ul>
    </div>

    <div>
      <h2 class="text-2xl font-semibold text-blue-300 mb-2">📘 Study Tips</h2>
      <ul class="list-disc list-inside text-gray-300">
        <li>Set aside 25–30 minutes of focused study time followed by a 5-minute break (Pomodoro Technique).</li>
        <li>Use the <span class="text-blue-400 font-semibold">Smart Quiz Generator</span> to reinforce weak subjects.</li>
        <li>Upload your notes regularly in the <span class="text-blue-400 font-semibold">Upload & Organize</span> section for easier review.</li>
        <li>Summarize each lesson in your own words to improve retention.</li>
      </ul>
    </div>

    <div>
      <h2 class="text-2xl font-semibold text-blue-300 mb-2">📊 Suggested Study Plan</h2>
      <p class="text-gray-300">
        🔹 Monday–Tuesday: Focus on Networking (practice terminology and IP addressing)<br>
        🔹 Wednesday: HTML & CSS layout challenges<br>
        🔹 Thursday: PHP project exercises<br>
        🔹 Friday: Quick review quizzes across all subjects
      </p>
    </div>

  </div>

  <button onclick="showSection('home')" class="back-button">🔙 Back to Home</button>
</section>

<!-- SCHEDULE SESSIONS SECTION -->
<section id="scheduleSessions" class="hidden p-10">
  <h1 class="text-4xl font-bold mb-8 text-blue-400">📅 Schedule Study Sessions</h1>
  <p class="text-gray-300 text-lg mb-10">
    Plan your study sessions in advance. Add subjects, dates, and time slots to keep your learning consistent and organized.
  </p>

  <!-- Schedule Form -->
  <div class="bg-gradient-to-br from-gray-800 to-gray-700 p-10 rounded-3xl shadow-xl mb-10">
    <form id="sessionForm" class="space-y-6">
      <div>
        <label class="block text-gray-300 font-semibold mb-2">📘 Subject</label>
        <select id="subject" class="w-full bg-gray-900 border border-gray-700 text-gray-200 p-3 rounded-lg focus:ring focus:ring-blue-500">
          <option value="">-- Select Subject --</option>
          <option>🐍 Python Fundamentals</option>
          <option>🌐 HTML & CSS Fundamentals</option>
          <option>💻 PHP Fundamentals</option>
          <option>☕ Java Fundamentals</option>
          <option>🖧 Networking Fundamentals</option>
        </select>
      </div>

      <div>
        <label class="block text-gray-300 font-semibold mb-2">📅 Date</label>
        <input type="date" id="date" class="w-full bg-gray-900 border border-gray-700 text-gray-200 p-3 rounded-lg focus:ring focus:ring-blue-500">
      </div>

      <div>
        <label class="block text-gray-300 font-semibold mb-2">⏰ Time</label>
        <input type="time" id="time" class="w-full bg-gray-900 border border-gray-700 text-gray-200 p-3 rounded-lg focus:ring focus:ring-blue-500">
      </div>

      <div>
        <label class="block text-gray-300 font-semibold mb-2">📝 Notes</label>
        <textarea id="notes" rows="3" placeholder="Add session goals or reminders..." class="w-full bg-gray-900 border border-gray-700 text-gray-200 p-3 rounded-lg focus:ring focus:ring-blue-500"></textarea>
      </div>

      <button type="button" onclick="addSession()" class="px-8 py-3 bg-blue-500 hover:bg-blue-600 text-white rounded-xl font-semibold shadow-lg transition">
        ➕ Add Session
      </button>
    </form>
  </div>

  <!-- Scheduled Sessions List -->
  <div>
    <h2 class="text-2xl font-semibold text-blue-300 mb-4">📖 Upcoming Sessions</h2>
    <ul id="sessionList" class="space-y-4 text-gray-200">
      <li class="text-gray-400 italic">No scheduled sessions yet.</li>
    </ul>
  </div>

    <button onclick="showSection('home')" class="back-button">🔙 Back to Home</button>
</section> <!-- ✅ CLOSES scheduleSessions section properly -->

<!-- ✅ ACHIEVEMENTS SECTION (now outside scheduleSessions) -->
<section id="achievements" class="hidden p-10">
  <h1 class="text-4xl font-bold mb-8 text-blue-400">🏆 Achievements</h1>
  <p class="text-gray-300 text-lg mb-10">
    Celebrate your milestones and progress throughout your study journey. Achievements are unlocked based on your activity and quiz performance.
  </p>

  <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">

    <!-- Achievement 1 -->
    <div class="bg-gradient-to-br from-gray-800 to-gray-700 p-6 rounded-2xl shadow-lg hover:shadow-blue-600/40 transition-all duration-300">
      <h2 class="text-2xl font-semibold text-blue-300 mb-2">🎯 Quick Starter</h2>
      <p class="text-gray-400">Created your first reviewer.</p>
    </div>

    <!-- Achievement 2 -->
    <div class="bg-gradient-to-br from-gray-800 to-gray-700 p-6 rounded-2xl shadow-lg hover:shadow-blue-600/40 transition-all duration-300">
      <h2 class="text-2xl font-semibold text-blue-300 mb-2">📚 Study Streak</h2>
      <p class="text-gray-400">Completed study sessions for 5 days in a row.</p>
    </div>

    <!-- Achievement 3 -->
    <div class="bg-gradient-to-br from-gray-800 to-gray-700 p-6 rounded-2xl shadow-lg hover:shadow-blue-600/40 transition-all duration-300">
      <h2 class="text-2xl font-semibold text-blue-300 mb-2">🧠 Quiz Master</h2>
      <p class="text-gray-400">Scored 90% or higher on any quiz.</p>
    </div>

    <!-- Achievement 4 -->
    <div class="bg-gradient-to-br from-gray-800 to-gray-700 p-6 rounded-2xl shadow-lg hover:shadow-blue-600/40 transition-all duration-300">
      <h2 class="text-2xl font-semibold text-blue-300 mb-2">📈 Consistent Learner</h2>
      <p class="text-gray-400">Tracked progress across all 5 subjects.</p>
    </div>

    <!-- Achievement 5 -->
    <div class="bg-gradient-to-br from-gray-800 to-gray-700 p-6 rounded-2xl shadow-lg hover:shadow-blue-600/40 transition-all duration-300">
      <h2 class="text-2xl font-semibold text-blue-300 mb-2">🚀 Upload Hero</h2>
      <p class="text-gray-400">Uploaded at least 10 files to your study library.</p>
    </div>

    <!-- Achievement 6 -->
    <div class="bg-gradient-to-br from-gray-800 to-gray-700 p-6 rounded-2xl shadow-lg hover:shadow-blue-600/40 transition-all duration-300">
      <h2 class="text-2xl font-semibold text-blue-300 mb-2">🏅 All-Rounder</h2>
      <p class="text-gray-400">Completed a quiz in every subject category.</p>
    </div>

  </div>

  <button onclick="showSection('home')" class="back-button">🔙 Back to Home</button>
</section>



</main>

<!-- Tailwind Reusable Classes -->
<style>
.subject-link {
  display: block;
  background: #1f2937;
  padding: 1.5rem;
  border-radius: 0.75rem;
  transition: all 0.3s;
  box-shadow: 0 0 10px rgba(59,130,246,0.2);
}
.subject-link:hover {
  background: #374151;
  transform: translateY(-5px);
  box-shadow: 0 0 20px rgba(59,130,246,0.4);
}
.back-button {
  margin-top: 3rem;
  color: #60a5fa;
  font-weight: 600;
  transition: 0.3s;
}
.back-button:hover {
  color: #3b82f6;
}
</style>

<script>
// Show and hide sections dynamically
function showSection(id) {
  document.querySelectorAll('main section').forEach(sec => sec.classList.add('hidden'));
  const target = document.getElementById(id);
  if (target) target.classList.remove('hidden');
}

// Toggle subject dropdown
function toggleSubjects() {
  const list = document.getElementById('subjectList');
  const arrow = document.getElementById('arrow');
  list.classList.toggle('hidden');
  arrow.classList.toggle('rotate-180');
}
</script>

</body>
</html>  