<?php
session_start();

// Redirect user back to login if not logged in
if (!isset($_SESSION['user_name'])) {
    header("Location: login.html");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>StudyCoach - Dashboard</title>
<script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="h-screen flex text-white" style="background: linear-gradient(to bottom, #0f172a, #1e293b);">

<!-- Sidebar -->
<aside class="w-64 bg-gray-900 flex flex-col p-6">
  <h1 class="text-2xl font-bold mb-10 text-blue-400">📘 StudyCoach</h1>
  <nav class="flex flex-col space-y-4">
    <a href="mainpage.html" class="text-left hover:text-blue-400 transition transform hover:scale-110">🏠 Home</a>

    <!-- Create Reviewer Dropdown -->
    <div>
      <button onclick="toggleSubjects()" class="w-full text-left hover:text-blue-400 transition flex items-center justify-between transform hover:scale-110">
        ➕ Create Reviewer 
        <span id="arrow" class="transform transition-transform">▼</span>
      </button>

      <!-- Subject list -->
      <div id="subjectList" class="hidden mt-2 ml-4 flex flex-col space-y-2">
        <a href="create_python.php" class="hover:text-blue-300 transition transform hover:scale-110">🐍 Python Fundamentals</a>
        <a href="create_htmlcss.php" class="hover:text-blue-300 transition transform hover:scale-110">🌐 HTML & CSS Fundamentals</a>
        <a href="create_php.php" class="hover:text-blue-300 transition transform hover:scale-110">💻 PHP Fundamentals</a>
        <a href="create_java.php" class="hover:text-blue-300 transition transform hover:scale-110">☕ Java Fundamentals</a>
        <a href="create_networking.php" class="hover:text-blue-300 transition transform hover:scale-110">🖧 Networking Fundamentals</a>
      </div>
    </div>

    <!-- Smart Quiz Generator -->
    <button onclick="showSection('quiz')" class="text-left hover:text-blue-400 transition transform hover:scale-110">🧠 Smart Quiz Generator</button>

    <!-- My Reviewers -->
    <button onclick="showSection('myReviewers')" class="text-left hover:text-blue-400 transition transform hover:scale-110">📚 My Reviewers</button>

    <button onclick="showSection('studyTracker')" class="text-left hover:text-blue-400 transition transform hover:scale-110">📊 Study Tracker</button>

    <!-- Exam Schedules -->
    <button onclick="showSection('scheduleSessions')" class="text-left hover:text-blue-400 transition transform hover:scale-110">📅 Schedule Sessions</button>

    <a href="dashboard.php" 
       class="text-1xl text-blue-400 hover:text-blue-700 font-bold transition transform hover:scale-110">
       🔙 Return to Dashboard
    </a>

    <!-- Logout button -->
    <a href="logout.php"
       onclick="return confirm('Are you sure you want to log out?');"
       class="text-left hover:text-red-400 transition transform hover:scale-110">
       🚪 Logout
    </a>
  </nav>
</aside>

<!-- Main Content -->
<main class="flex-1 p-10 overflow-y-auto">  

  <!-- HOME SECTION -->
  <section id="home">
    <h1 class="text-4xl font-bold mb-10 text-blue-400">
      WELCOME TO STUDYCOACH: DASHBOARD
    </h1>
    <p class="text-xl text-gray-300 mb-8">
      👋 Hello, <span class="text-blue-400 font-semibold"><?php echo htmlspecialchars($_SESSION['user_name']); ?></span>!
    </p>

    <!-- Example cards -->
    <div onclick="showSection('uploadOrganize')"
     class="cursor-pointer block bg-gradient-to-br from-gray-800 to-gray-700 p-10 rounded-3xl shadow-xl hover:shadow-blue-600/50 hover:-translate-y-2 transition-all duration-300">
       <h2 class="text-2xl font-semibold mb-3 text-blue-400">📂 Upload & Organize</h2>
       <p class="text-gray-300 text-lg">
          Easily upload study materials, notes, and documents. Automatically organize them by subjects or topics for faster access.
       </p>
    </div>

    <div onclick="showSection('myReviewers')" 
      class="block bg-gradient-to-br from-gray-800 to-gray-700 p-10 rounded-3xl shadow-xl hover:shadow-blue-600/50 hover:-translate-y-2 transition-all duration-300 mt-8">
      <h2 class="text-2xl font-semibold mb-3 text-blue-400">📚 My Reviewers</h2>
      <p class="text-gray-300 text-lg">
        Access all your saved reviewers, practice tests, and summaries in one place for quick study sessions.
      </p>
    </div>

    <div onclick="showSection('studyTracker')" 
      class="cursor-pointer block bg-gradient-to-br from-gray-800 to-gray-700 p-10 rounded-3xl shadow-xl hover:shadow-blue-600/50 hover:-translate-y-2 transition-all duration-300 mt-8">
      <h2 class="text-2xl font-semibold mb-3 text-blue-400">📊 Study Tracker</h2>
      <p class="text-gray-300 text-lg">Track your progress with visual indicators to help you see what subjects or topics you need to review more.</p>
    </div>
  </section>

  <!-- Keep all other sections here (quiz, uploadOrganize, etc.) -->
  <!-- ... Your existing section code continues unchanged ... -->

</main>

<!-- Reusable Tailwind CSS classes -->
<style>
.subject-link {
  display: block;
  background: #1f2937;
  padding: 1.5rem;
  border-radius: 0.75rem;
  transition: all 0.3s;
  box-shadow: 0 0 10px rgba(59,130,246,0.2);
}
.subject-link:hover {
  background: #374151;
  transform: translateY(-5px);
  box-shadow: 0 0 20px rgba(59,130,246,0.4);
}
.back-button {
  margin-top: 3rem;
  color: #60a5fa;
  font-weight: 600;
  transition: 0.3s;
}
.back-button:hover {
  color: #3b82f6;
}
</style>

<script>
function showSection(id) {
  document.querySelectorAll('main section').forEach(sec => sec.classList.add('hidden'));
  const target = document.getElementById(id);
  if (target) target.classList.remove('hidden');
}

function toggleSubjects() {
  const list = document.getElementById('subjectList');
  const arrow = document.getElementById('arrow');
  list.classList.toggle('hidden');
  arrow.classList.toggle('rotate-180');
}
</script>

</body>
</html>
