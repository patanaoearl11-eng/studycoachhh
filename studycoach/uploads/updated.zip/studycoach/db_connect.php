<?php
$servername = "localhost";
$username = "root";   // Default for XAMPP
$password = "";       // Default for XAMPP
$dbname = "studycoach";  // Replace with your database name

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
?>
